# terminator

> Arrange multiple GNOME terminals in one window.

- Start terminator window:

`terminator`

- Start with a fullscreen window:

`terminator -f`

- Split terminals horizontally:

`Ctrl + Shift + O`

- Split terminals vertically:

`Ctrl + Shift + E`

- Open new tab:

`Ctrl + Shift + T`
