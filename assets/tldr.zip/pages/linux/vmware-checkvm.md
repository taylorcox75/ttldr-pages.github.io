# vmware-checkvm

> Checks to see if the current host is a VMWare VM or not.

- Return the current VMWare software version (exit status determines whether the system is a VM or not):

`vmware-checkvm`

- Return the VMWare hardware version:

`vmware-checkvm -h`
