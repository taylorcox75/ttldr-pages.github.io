# manpath

> Determine the search path for manual pages.

- Display the search path used to find man pages:

`manpath`

- Show the entire global manpath:

`manpath --global`
