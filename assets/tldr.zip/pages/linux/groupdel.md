# groupdel

> Delete existing user groups from the system.

- Delete an existing group:

`groupdel {{group_name}}`
